// Create an abstract class Shape with the following specifications:
// An abstract method surface_area () of return type double
// An abstract method volume() of return type double

public abstract class Shape {
    // abstract method to calculate surface area
    public abstract double surface_area();
    // abstract method to calculate volume
    public abstract double volume();
}

// Create a class Sphere that extends the Shape class with the following specifications:
// Attributes:
// Radius
// Constructor:
// Implement a parameterized constructor needed to initialize the data.
// toString:
// Implement a toString method that prints out the surface area and volume.

class Sphere extends Shape {
    private double radius;
    
    public Sphere(double radius) {
        this.radius = radius;
    }
    
    @Override
    public double surface_area() {
        return 4 * Math.PI * radius * radius;
    }
    
    @Override
    public double volume() {
        return (4.0/3.0) * Math.PI * radius * radius * radius;
    }
    
    @Override
    public String toString() {
        return "Sphere [radius=" + radius + ", surface_area=" + surface_area() + ", volume=" + volume() + "]";
    }
}

// Create a class Cylinder that extends the Shape class with the following specifications:
// Attributes:
// Radius, height - both of type double
// Constructor:
// Implement a parameterized constructor to initialize the data.
// toString:
// Implement a toString method that prints out the surface area and volume.

class Cylinder extends Shape {
    private double radius;
    private double height;
    
    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    
    @Override
    public double surface_area() {
        return 2 * Math.PI * radius * (radius + height);
    }
    
    @Override
    public double volume() {
        return Math.PI * radius * radius * height;
    }
    
    @Override
    public String toString() {
        return "Cylinder [radius=" + radius + ", height=" + height + ", surface_area=" + surface_area() + ", volume=" + volume() + "]";
    }
}

// Create a class Cone that extends the Shape class with the following specifications:
// Attributes:
// Radius, height - both of type double
// Constructor:
// Implement a parameterized constructor to initialize the data.
// toString:
// Implement a toString method that prints out the surface area and volume.

class Cone extends Shape {
    private double radius;
    private double height;

    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    public double surface_area() {
        double slantHeight = Math.sqrt(radius * radius + height * height);
        return Math.PI * radius * (radius + slantHeight);
    }

    @Override
    public double volume() {
        return (1.0/3.0) * Math.PI * radius * radius * height;
    }

    @Override
    public String toString() {
        return "Cone [radius=" + radius + ", height=" + height + ", surface_area=" + surface_area() + ", volume=" + volume() + "]";
    }
}

// Create a driver class named ShapeArray with the following specifications:
// Instantiate one sphere.
// Instantiate one cylinder.
// Instantiate one cone.
// Store the class instances into an array named shapeArray.
// Loop through the array and print out the instance data of each object using the object instance's toString method.

class ShapeArray {
    public static void main(String[] args) {
        // Instantiate one sphere
        Sphere sphere = new Sphere(5.0);
        
        // Instantiate one cylinder
        Cylinder cylinder = new Cylinder(3.0, 7.0);
        
        // Instantiate one cone
        Cone cone = new Cone(4.0, 6.0);
        
        // Store the class instances into an array named shapeArray
        Shape[] shapeArray = {sphere, cylinder, cone};
        
        // Loop through the array and print out the instance data of each object using the object instance's toString method
        for (Shape shape : shapeArray) {
            System.out.println(shape.toString());
        }
    }
}